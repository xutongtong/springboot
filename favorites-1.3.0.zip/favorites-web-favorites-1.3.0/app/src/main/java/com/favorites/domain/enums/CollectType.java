package com.favorites.domain.enums;

public enum CollectType {

	PUBLIC, PRIVATE
}
